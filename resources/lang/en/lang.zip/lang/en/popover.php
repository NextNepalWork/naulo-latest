<?php
return [
    'vendor_cover_image'                =>  'Your uploaded image will appear at vendor details page',
    'vendor_cat_add'                    =>  'Search categories and add. Your selected categories will displayed at vendor home page',
    'show_map_extra_label'              =>  "Enable showing Store location map on store left sidebar",
    'show_contact_form_extra_label'     =>  "Enable showing contact vendor form on store left sidebar",
    'vendor_commission_msg'             =>  "How much amount (%) a vendor will get from each order"
];
